package com.example.plaga;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ResumenAlertaActivity extends AppCompatActivity {

    TextView tvNombrePlaga, tvLatitud, tvLongitud;
    ImageView imgPlanta;
    Button btnConfirmar, btnVolverEditar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumen_alerta);

        tvNombrePlaga = findViewById(R.id.tvNombrePlaga);
        tvLatitud = findViewById(R.id.tvLatitud);
        tvLongitud = findViewById(R.id.tvLongitud);
        imgPlanta = findViewById(R.id.imgPlanta);
        btnConfirmar = findViewById(R.id.btnConfirmar);
        btnVolverEditar = findViewById(R.id.btnVolverEditar);

        String nombre = getIntent().getStringExtra("NOMBRE_PLAGA");
        if (nombre != null && !nombre.isEmpty()) {
            tvNombrePlaga.setText(nombre);
        }

        if (AppCache.capturedBitmap != null) {
            imgPlanta.setImageBitmap(AppCache.capturedBitmap);
        }

        btnConfirmar.setOnClickListener(v -> {
            Toast.makeText(this, "¡Reporte enviado exitosamente!", Toast.LENGTH_LONG).show();
            AppCache.capturedBitmap = null;
            Intent intent = new Intent(ResumenAlertaActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });

        btnVolverEditar.setOnClickListener(v -> finish());
    }
}
