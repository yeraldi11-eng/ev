package com.example.plaga;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText etDni, etPassword;
    Button btnIngresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etDni = findViewById(R.id.etDni);
        etPassword = findViewById(R.id.etPassword);
        btnIngresar = findViewById(R.id.btnIngresar);

        btnIngresar.setOnClickListener(v -> {
            String dni = etDni.getText().toString().trim();
            String pass = etPassword.getText().toString().trim();

            if (dni.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Por favor ingresa DNI y contraseña", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(LoginActivity.this, RegistroPlagaActivity.class);
            startActivity(intent);
        });
    }
}
