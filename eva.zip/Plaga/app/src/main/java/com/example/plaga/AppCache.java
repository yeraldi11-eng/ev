package com.example.plaga;

import android.graphics.Bitmap;

public class AppCache {
    public static Bitmap capturedBitmap = null;
}
