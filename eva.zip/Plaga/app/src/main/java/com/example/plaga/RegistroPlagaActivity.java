package com.example.plaga;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class RegistroPlagaActivity extends AppCompatActivity {

    EditText etNombrePlaga;
    Button btnContinuar, btnTomarFoto;
    ImageView ivFotoPlanta;
    LinearLayout layoutPlaceholderFoto;

    private final ActivityResultLauncher<Intent> cameraLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Bundle extras = result.getData().getExtras();
                    if (extras != null) {
                        Bitmap imageBitmap = (Bitmap) extras.get("data");
                        if (imageBitmap != null) {
                            AppCache.capturedBitmap = imageBitmap;
                            ivFotoPlanta.setImageBitmap(imageBitmap);
                            ivFotoPlanta.setVisibility(View.VISIBLE);
                            layoutPlaceholderFoto.setVisibility(View.GONE);
                            Toast.makeText(this, "Fotografía capturada exitosamente", Toast.LENGTH_SHORT).show();
                            if (etNombrePlaga.getText().toString().isEmpty()) {
                                etNombrePlaga.setText("Mosca blanca");
                            }
                        }
                    }
                }
            }
    );

    private final ActivityResultLauncher<String> requestPermissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            isGranted -> {
                if (isGranted) {
                    launchCamera();
                } else {
                    Toast.makeText(this, "Se requiere permiso de cámara para tomar la fotografía", Toast.LENGTH_LONG).show();
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_plaga);

        etNombrePlaga = findViewById(R.id.etNombrePlaga);
        btnContinuar = findViewById(R.id.btnContinuar);
        btnTomarFoto = findViewById(R.id.btnTomarFoto);
        ivFotoPlanta = findViewById(R.id.ivFotoPlanta);
        layoutPlaceholderFoto = findViewById(R.id.layoutPlaceholderFoto);

        // Restore bitmap if returning from summary
        if (AppCache.capturedBitmap != null) {
            ivFotoPlanta.setImageBitmap(AppCache.capturedBitmap);
            ivFotoPlanta.setVisibility(View.VISIBLE);
            layoutPlaceholderFoto.setVisibility(View.GONE);
        }

        btnTomarFoto.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                launchCamera();
            } else {
                requestPermissionLauncher.launch(Manifest.permission.CAMERA);
            }
        });

        btnContinuar.setOnClickListener(v -> {
            String nombrePlaga = etNombrePlaga.getText().toString().trim();

            if (nombrePlaga.isEmpty()) {
                Toast.makeText(this, "Ingrese el nombre de la plaga", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(RegistroPlagaActivity.this, ResumenAlertaActivity.class);
            intent.putExtra("NOMBRE_PLAGA", nombrePlaga);
            startActivity(intent);
        });
    }

    private void launchCamera() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraLauncher.launch(takePictureIntent);
    }
}
